class SteppingPiece
end
